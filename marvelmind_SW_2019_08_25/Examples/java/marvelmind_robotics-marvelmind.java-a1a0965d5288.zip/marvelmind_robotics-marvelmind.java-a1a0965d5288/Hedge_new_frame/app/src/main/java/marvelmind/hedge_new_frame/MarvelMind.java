package marvelmind.hedge_new_frame;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbManager;
import android.widget.TextView;

import com.hoho.android.usbserial.driver.UsbSerialDriver;
import com.hoho.android.usbserial.driver.UsbSerialPort;
import com.hoho.android.usbserial.driver.UsbSerialProber;

import org.w3c.dom.Text;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.Semaphore;

public class MarvelMind {

    private static final int BUFSIZE = 4096;
    private static final int PDGSIZE = 29;
    private static final short PDGHEADER[] = { 0xff, 0x47, 0x11, 0x00, 0x16 };


    /**
     * Read usb data stream
     * @param   port
     * @return
     */
    public static short[] read_stream(UsbSerialPort port) throws IOException {
        int numBytesRead;
        int pdgEnd = 0;

        short[] positionDatagram = new short[PDGSIZE];
        while (true) {
            byte buffer[] = new byte[BUFSIZE];
            numBytesRead = port.read(buffer, 1000);

            if (numBytesRead>0){
                int i=0;
                boolean copy=false;
                for (int j=0; j<numBytesRead; j++) {
                    if (buffer[j]==-1) {    
                        i=j;                
                        copy=true;
                        break;
                    }
                }

                if (copy) {
                    for (; i < numBytesRead; i++) {
                        positionDatagram[pdgEnd++] = (short) (buffer[i] & 0xff);    
                        if (pdgEnd == PDGSIZE) break;
                    }
                }
                if (pdgEnd==PDGSIZE){
                    return positionDatagram;
                }
            }
            else if (numBytesRead<0) {
                throw new IOException();
            }
            break;
        }
        return positionDatagram;
    }

    /**
     * Parse hedge_frame
     * @param frame
     * @return Data description:
     *          data[0] - timetick
     *          data[1] - hedge id
     *          data[2] - X (mm)
     *          data[3] - Y (mm)
     *          data[4] - Z (mm)
     */
    public static int[] parse_frame(short[] frame) {
        int[] data = new int[5];

        for ( int i = 0; i < PDGHEADER.length; i++ ){
            if (frame[i] != PDGHEADER[i] ) {
                return data;
            }
        }

        int crc = frame[27] | ( frame[28] << 8 );
        if (ModRTU_CRC(frame, PDGSIZE-2) != crc) return data;

        data[0]=frame[5] |
                (frame[6]<<8) |
                (frame[7]<<16) |
                (frame[8]<<24);

        data[1]= frame[9] |
                (frame[10]<<8) |
                (frame[11]<<16) |
                (frame[12]<<24) ;

        data[2]= frame[13] |
                (frame[14]<<8) |
                (frame[15]<<16) |
                (frame[16]<<24) ;

        data[3]= frame[17] |
                (frame[18]<<8) |
                (frame[19]<<16) |
                (frame[20]<<24) ;

        return data;
    }

    /**
     * CRC method
     * @param buf
     * @param len
     * @return crc
     */
    private static int ModRTU_CRC(short[] buf, int len) {
        int crc = 0xffff;
        for (int ind = 0; ind < len; ind++ ) {
            crc ^= (int)buf[ind] & 0xff;
            for ( int i = 8; i != 0 ; i-- ) {
                if ( (crc & 0x0001) != 0 ) {
                    crc >>= 1;
                    crc ^= 0xA001;
                } else crc >>= 1;
            }
        }
        return crc;
    }

}
