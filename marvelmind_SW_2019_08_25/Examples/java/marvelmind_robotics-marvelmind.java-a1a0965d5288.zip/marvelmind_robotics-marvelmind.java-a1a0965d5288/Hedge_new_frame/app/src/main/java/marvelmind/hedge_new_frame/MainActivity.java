package marvelmind.hedge_new_frame;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.hoho.android.usbserial.driver.CdcAcmSerialDriver;
import com.hoho.android.usbserial.driver.ProbeTable;
import com.hoho.android.usbserial.driver.UsbSerialDriver;
import com.hoho.android.usbserial.driver.UsbSerialPort;
import com.hoho.android.usbserial.driver.UsbSerialProber;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.Semaphore;

import static marvelmind.hedge_new_frame.MarvelMind.parse_frame;

public class MainActivity extends AppCompatActivity {

    private TextView tv1;
    private UsbManager usbManager;
    private UsbSerialProber usbSerialProber;
    private short positionDatagram[];
    private int pdgEnd;
    private int x, y, z;
    private int timestamp;
    private ArrayList<TableItem> listValues=new ArrayList<TableItem>();
    private ItemAdapter listAdapter;
    private Semaphore semUsbPermitted = new Semaphore(1);
    private ListView listView;

    enum Status {CONNECTING, WAIT_DATA, DATA_READY }
    private Status status;

    public class TableItem {
        public int x, y, z;
        public int timestamp;
        public TableItem(int timestamp, int x, int y, int z){
            this.timestamp=timestamp;
            this.x=x;
            this.y=y;
            this.z=z;
        }
    }

    public class ItemAdapter extends ArrayAdapter<TableItem> {
        private ArrayList<TableItem> objects;

        public ItemAdapter(Context context, int textViewResourceId, ArrayList<TableItem> objects) {
            super(context, textViewResourceId, objects);
            this.objects = objects;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            View v = convertView;

            if (v == null) {
                LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                v = inflater.inflate(R.layout.row_layout, null);
            }

            TableItem i = objects.get(position);
            if (i != null) {
                TextView tvTimestamp = (TextView) v.findViewById(R.id.timestamp);
                TextView tvX = (TextView) v.findViewById(R.id.x);
                TextView tvY = (TextView) v.findViewById(R.id.y);
                TextView tvZ = (TextView) v.findViewById(R.id.z);

                if (tvTimestamp != null){
                    tvTimestamp.setText(Integer.toString(i.timestamp));
                }
                if (tvX != null) {
                    tvX.setText(Integer.toString(i.x));
                }
                if (tvY != null) {
                    tvY.setText(Integer.toString(i.y));
                }
                if (tvZ != null) {
                    tvZ.setText(Integer.toString(i.z));
                }
            }

            return v;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        status=Status.CONNECTING;
        tv1 = (TextView) findViewById(R.id.textView1);
        listView = (ListView) findViewById(R.id.listView);
        listAdapter = new ItemAdapter(this, R.layout.row_layout, listValues);
        listView.setAdapter(listAdapter);

        usbManager = (UsbManager) getSystemService(Context.USB_SERVICE);
        ProbeTable probeTable = new ProbeTable();
        probeTable.addProduct(0x483, 0x5740, CdcAcmSerialDriver.class);
        usbSerialProber = new UsbSerialProber(probeTable);

        Timer mTimer;
        GuiTimer guiTimer;
        mTimer = new Timer();
        guiTimer = new GuiTimer();
        mTimer.schedule(guiTimer, 0, 500);

        Thread parserThread = new Thread(new Runnable() {
            @Override
            public void run() {
                scanPorts();
            }
        });
        parserThread.start();
    }

    private final String ACTION_USB_PERMISSION =
            "marvelmind.hedge_new_frame.USB_PERMISSION";
    private final BroadcastReceiver mUsbReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (ACTION_USB_PERMISSION.equals(action)) {
                synchronized (this) {
                    UsbDevice device = (UsbDevice) intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                    if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                        if (device != null) {
                            //permission granted; continue program
                            semUsbPermitted.release();
                        }
                    } else {
                        // user didn't grant permission
                        finish();
                    }
                }
            }
        }
    };

    private void scanPorts() {
        while (true) {
            List<UsbSerialDriver> availableDrivers = usbSerialProber.findAllDrivers(usbManager);
            if (!availableDrivers.isEmpty()) {
                UsbSerialDriver driver = availableDrivers.get(0);

                UsbDevice device=driver.getDevice();

                PendingIntent permissionIntent = PendingIntent.getBroadcast(this, 0, new Intent(
                        ACTION_USB_PERMISSION), 0);

                IntentFilter filter = new IntentFilter(ACTION_USB_PERMISSION);
                registerReceiver(mUsbReceiver, filter);

                usbManager.requestPermission(device, permissionIntent);
                semUsbPermitted.acquireUninterruptibly();

                UsbDeviceConnection connection = usbManager.openDevice(device);


                if (connection != null) {
                    UsbSerialPort port = driver.getPorts().get(0);
                    try {
                        port.open(connection);
                        port.setParameters(9600, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE);

                        while(true) {
                            short[] frame_data = MarvelMind.read_stream(port);
                            int[] data = parse_frame(frame_data);

                            timestamp = data[0];
                            x = data[1];
                            y = data[2];
                            z = data[3];

                            status = Status.DATA_READY;

                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    TableItem newitem=new TableItem(timestamp, x, y, z);
                                    listValues.add(newitem);
                                    if (listValues.size()>100) listValues.remove(0);
                                    listAdapter.notifyDataSetChanged();
                                    listView.setSelection(listAdapter.getCount() - 1);
                                    tv1.setText("Receiving data");
                                }
                            });

                        }

                    } catch (IOException e) {

                    } finally {
                        try {
                            port.close();
                        }
                        catch (IOException e) {
                        }
                        pdgEnd=0;
                        status=Status.CONNECTING;
                        listValues.clear();
                        listAdapter.notifyDataSetChanged();
                    }
                }
            }
        }
    }

    class GuiTimer extends TimerTask {

        @Override
        public void run() {
            runOnUiThread(new Runnable() {

                @Override
                public void run() {
                    switch (status){
                        case CONNECTING:
                            tv1.setText("Please connect Hedge");
                            break;
                        case WAIT_DATA:
                            tv1.setText("Connected. Waiting for data...");
                            break;
                        default:
                            tv1.setText("Waiting for connection");
                            break;
                    }
                }
            });
        }
    }
}
