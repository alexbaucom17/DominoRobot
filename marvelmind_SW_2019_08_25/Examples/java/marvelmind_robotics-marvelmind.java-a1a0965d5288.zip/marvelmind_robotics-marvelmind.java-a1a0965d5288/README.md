# MarvelMind.java

Marvelmind.java includes simple java class which is allow to implement within your project high resolution marvelmind protocol. Written by Alexey Gaibura.
(ideogaib@gmail.com)
[Download](https://bitbucket.org/marvelmind_robotics/marvelmind.java/get/8e3110bb200e.zip)



# Hedge_new_frame

Hedge_new_frame includes simple android studio project using MarvelMind.java library.



# Attributes

### PDGHEADER
head of high resolution frame
### PDGSIZE
size of high resolution frame



# Methods

### read_stream(UsbSerialPort port) throws IOException 
returns marvelmind high resolution frame
### parse_frame(short[] frame) 
returns [timetick, hedge id, X(mm), Y(mm), Z(mm)]
### ModRTU_CRC(short[] buf, int len)
returns CRC
 


# Required libraries:
[UsbSerialAndroid library for Android](https://github.com/mik3y/usb-serial-for-android)